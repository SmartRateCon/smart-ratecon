#!/bin/bash
pip install -r requirements.txt
python app.py